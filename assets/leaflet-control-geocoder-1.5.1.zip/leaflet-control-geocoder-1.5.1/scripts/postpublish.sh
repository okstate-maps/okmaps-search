git checkout master
git branch -D build
